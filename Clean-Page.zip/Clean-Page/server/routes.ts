import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.payments.get.path, async (req, res) => {
    const payment = await storage.getPaymentRequest(Number(req.params.id));
    if (!payment) {
      return res.status(404).json({ message: 'Payment request not found' });
    }
    res.json(payment);
  });

  app.post(api.payments.process.path, async (req, res) => {
    const payment = await storage.getPaymentRequest(Number(req.params.id));
    if (!payment) {
      return res.status(404).json({ message: 'Payment request not found' });
    }
    
    // In a real app we'd process payment here
    const updated = await storage.updatePaymentStatus(Number(req.params.id), 'completed');
    res.json(updated);
  });

  app.post(api.payments.cancel.path, async (req, res) => {
    const payment = await storage.getPaymentRequest(Number(req.params.id));
    if (!payment) {
      return res.status(404).json({ message: 'Payment request not found' });
    }
    
    const updated = await storage.updatePaymentStatus(Number(req.params.id), 'cancelled');
    res.json(updated);
  });

  return httpServer;
}