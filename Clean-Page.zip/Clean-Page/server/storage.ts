import { db } from "./db";
import {
  paymentRequests,
  type InsertPaymentRequest,
  type PaymentRequest
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getPaymentRequest(id: number): Promise<PaymentRequest | undefined>;
  updatePaymentStatus(id: number, status: string): Promise<PaymentRequest>;
  createPaymentRequest(request: InsertPaymentRequest): Promise<PaymentRequest>;
}

export class DatabaseStorage implements IStorage {
  async getPaymentRequest(id: number): Promise<PaymentRequest | undefined> {
    const [request] = await db.select().from(paymentRequests).where(eq(paymentRequests.id, id));
    return request;
  }

  async updatePaymentStatus(id: number, status: string): Promise<PaymentRequest> {
    const [updated] = await db.update(paymentRequests)
      .set({ status })
      .where(eq(paymentRequests.id, id))
      .returning();
    return updated;
  }

  async createPaymentRequest(request: InsertPaymentRequest): Promise<PaymentRequest> {
    const [created] = await db.insert(paymentRequests).values(request).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();