import { storage } from "./storage";
import { db } from "./db";
import { paymentRequests } from "../shared/schema";

async function seed() {
  try {
    const existing = await db.select().from(paymentRequests);
    if (existing.length === 0) {
      const now = new Date();
      const expiresAt = new Date(now.getTime() + 15 * 60000); // 15 minutes from now
      
      await storage.createPaymentRequest({
        transactionId: "TTSP2P-2023-5872",
        recipient: "Justin Christopher (Jjc3217@gmail.com)",
        platform: "TikTok Shop",
        amount: "3 TikTok Lion",
        status: "pending",
        expiresAt: expiresAt
      });
      console.log("Seeded database");
    } else {
      console.log("Database already seeded");
    }
  } catch (err) {
    console.error("Error seeding:", err);
  } finally {
    process.exit(0);
  }
}

seed();