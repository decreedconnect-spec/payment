import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const paymentRequests = pgTable("payment_requests", {
  id: serial("id").primaryKey(),
  transactionId: text("transaction_id").notNull(),
  recipient: text("recipient").notNull(),
  platform: text("platform").notNull(),
  amount: text("amount").notNull(),
  status: text("status").notNull().default("pending"),
  expiresAt: timestamp("expires_at").notNull(),
});

export const insertPaymentRequestSchema = createInsertSchema(paymentRequests).omit({ id: true });
export type InsertPaymentRequest = z.infer<typeof insertPaymentRequestSchema>;
export type PaymentRequest = typeof paymentRequests.$inferSelect;