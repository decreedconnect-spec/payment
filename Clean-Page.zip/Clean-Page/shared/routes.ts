import { z } from 'zod';
import { paymentRequests } from './schema';

export const errorSchemas = {
  notFound: z.object({ message: z.string() }),
};

export const api = {
  payments: {
    get: {
      method: 'GET' as const,
      path: '/api/payments/:id' as const,
      responses: {
        200: z.custom<typeof paymentRequests.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    process: {
      method: 'POST' as const,
      path: '/api/payments/:id/process' as const,
      responses: {
        200: z.custom<typeof paymentRequests.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    cancel: {
      method: 'POST' as const,
      path: '/api/payments/:id/cancel' as const,
      responses: {
        200: z.custom<typeof paymentRequests.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}