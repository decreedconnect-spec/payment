import { motion } from "framer-motion";
import { CheckCircle2, Receipt } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PaymentSuccessProps {
  amount: string;
  transactionId: string;
  recipient: string;
}

export function PaymentSuccess({ amount, transactionId, recipient }: PaymentSuccessProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex flex-col items-center text-center py-8"
    >
      <motion.div 
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, type: "spring", stiffness: 200, damping: 20 }}
        className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mb-6"
      >
        <CheckCircle2 className="w-10 h-10 text-green-600 dark:text-green-500" />
      </motion.div>
      
      <h2 className="text-2xl font-bold mb-2 text-foreground">Payment Successful</h2>
      <p className="text-muted-foreground mb-8 max-w-[260px]">
        Your payment of <span className="font-semibold text-foreground">{amount}</span> to {recipient} has been processed.
      </p>

      <div className="w-full bg-secondary/50 rounded-xl p-4 mb-8 text-left space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Transaction ID</span>
          <span className="font-medium font-mono">{transactionId}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Status</span>
          <span className="font-medium text-green-600 dark:text-green-500">Completed</span>
        </div>
      </div>

      <Button variant="outline" className="w-full rounded-xl h-12 font-medium hover-elevate">
        <Receipt className="w-4 h-4 mr-2" />
        View Receipt
      </Button>
    </motion.div>
  );
}
