import { useState, useEffect } from "react";
import { Clock } from "lucide-react";

interface CountdownTimerProps {
  expiresAt: string | Date;
  onExpire?: () => void;
  isExpired?: boolean;
}

export function CountdownTimer({ expiresAt, onExpire, isExpired: initialIsExpired }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState<{ minutes: number; seconds: number } | null>(null);
  const [hasExpired, setHasExpired] = useState(initialIsExpired || false);

  useEffect(() => {
    if (initialIsExpired) {
      setHasExpired(true);
      return;
    }

    const targetDate = new Date(expiresAt).getTime();

    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setHasExpired(true);
        if (onExpire) onExpire();
        return null;
      }

      return {
        minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((difference % (1000 * 60)) / 1000),
      };
    };

    setTimeLeft(calculateTimeLeft());

    const timer = setInterval(() => {
      const remaining = calculateTimeLeft();
      if (!remaining) {
        clearInterval(timer);
      } else {
        setTimeLeft(remaining);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [expiresAt, onExpire, initialIsExpired]);

  if (hasExpired) {
    return (
      <div className="flex items-center gap-1.5 text-destructive font-medium bg-destructive/10 px-3 py-1.5 rounded-full text-sm">
        <Clock className="w-4 h-4" />
        <span>Expired</span>
      </div>
    );
  }

  if (!timeLeft) return null;

  // Add warning color if less than 3 minutes
  const isWarning = timeLeft.minutes < 3;

  return (
    <div className={`flex items-center gap-1.5 font-medium px-3 py-1.5 rounded-full text-sm transition-colors duration-300 ${
      isWarning 
        ? "text-orange-600 bg-orange-100 dark:text-orange-400 dark:bg-orange-950/50" 
        : "text-muted-foreground bg-secondary"
    }`}>
      <Clock className="w-4 h-4" />
      <span className="tabular-nums">
        {String(timeLeft.minutes).padStart(2, "0")}:{String(timeLeft.seconds).padStart(2, "0")}
      </span>
    </div>
  );
}
