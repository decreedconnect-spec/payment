import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import { PaymentView } from "@/pages/payment-view";

function Router() {
  return (
    <Switch>
      {/* Auto-load payment ID 1 on home */}
      <Route path="/" component={Home} />
      
      {/* Route for generic payment links if needed in the future */}
      <Route path="/payment/:id">
        {(params) => <PaymentView id={Number(params.id)} />}
      </Route>
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
