import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { PaymentRequest } from "@shared/schema";

export function usePayment(id: number) {
  return useQuery({
    queryKey: [api.payments.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.payments.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) {
        if (res.status === 404) throw new Error("Payment request not found");
        throw new Error("Failed to fetch payment details");
      }
      // Assuming response matches PaymentRequest exactly
      return res.json() as Promise<PaymentRequest>;
    },
    // Don't retry on 404s
    retry: (failureCount, error) => {
      if (error.message === "Payment request not found") return false;
      return failureCount < 3;
    }
  });
}

export function useProcessPayment() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.payments.process.path, { id });
      const res = await fetch(url, {
        method: api.payments.process.method,
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });
      
      if (!res.ok) {
        throw new Error("Failed to process payment");
      }
      
      return res.json() as Promise<PaymentRequest>;
    },
    onSuccess: (data, id) => {
      // Invalidate both the specific item and any lists if they existed
      queryClient.invalidateQueries({ queryKey: [api.payments.get.path, id] });
    },
  });
}

export function useCancelPayment() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.payments.cancel.path, { id });
      const res = await fetch(url, {
        method: api.payments.cancel.method,
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });
      
      if (!res.ok) {
        throw new Error("Failed to cancel payment");
      }
      
      return res.json() as Promise<PaymentRequest>;
    },
    onSuccess: (data, id) => {
      queryClient.invalidateQueries({ queryKey: [api.payments.get.path, id] });
    },
  });
}
