import { PaymentView } from "./payment-view";

export default function Home() {
  // Implementation Note: "On the home page (/), automatically fetch payment ID 1."
  // We accomplish this by rendering the PaymentView component directly with ID 1.
  return <PaymentView id={1} />;
}
