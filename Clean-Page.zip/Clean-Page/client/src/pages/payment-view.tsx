import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingBag, ShieldCheck, Lock, ChevronRight, XCircle, AlertCircle } from "lucide-react";
import { usePayment, useProcessPayment, useCancelPayment } from "@/hooks/use-payments";
import { CountdownTimer } from "@/components/countdown-timer";
import { PaymentSuccess } from "@/components/payment-success";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

interface PaymentViewProps {
  id: number;
}

export function PaymentView({ id }: PaymentViewProps) {
  const { data: payment, isLoading, error } = usePayment(id);
  const processMutation = useProcessPayment();
  const cancelMutation = useCancelPayment();
  const { toast } = useToast();
  
  // Local state for the fake 3s spinning delay before real mutation
  const [isSimulatingProcessing, setIsSimulatingProcessing] = useState(false);

  const handleProcessPayment = () => {
    setIsSimulatingProcessing(true);
    
    // Simulate network delay for that authentic processing feel
    setTimeout(() => {
      processMutation.mutate(id, {
        onSuccess: () => {
          setIsSimulatingProcessing(false);
          toast({
            title: "Payment Successful",
            description: "Your transaction was completed successfully.",
          });
        },
        onError: (err) => {
          setIsSimulatingProcessing(false);
          toast({
            variant: "destructive",
            title: "Payment Failed",
            description: err.message || "An error occurred while processing.",
          });
        }
      });
    }, 3000);
  };

  const handleCancelPayment = () => {
    cancelMutation.mutate(id, {
      onSuccess: () => {
        toast({
          title: "Payment Cancelled",
          description: "This payment request has been cancelled.",
        });
      }
    });
  };

  if (isLoading) {
    return <PaymentSkeleton />;
  }

  if (error || !payment) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center shadow-soft border-border/50">
          <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">Request Not Found</h2>
          <p className="text-muted-foreground">This payment request doesn't exist or has been removed.</p>
        </Card>
      </div>
    );
  }

  const isPending = payment.status === "pending";
  const isCompleted = payment.status === "completed";
  const isCancelled = payment.status === "cancelled";
  const isExpired = payment.status === "expired";
  
  const isActionable = isPending && !isSimulatingProcessing;

  return (
    <div className="min-h-screen flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-[420px]"
      >
        {/* Header/Brand Area */}
        <div className="flex items-center justify-center mb-6 text-foreground/80">
          <div className="bg-primary text-primary-foreground p-2.5 rounded-xl mr-3 shadow-md">
            <ShoppingBag className="w-5 h-5" />
          </div>
          <span className="font-bold tracking-tight text-xl">PayCheckout</span>
        </div>

        <Card className="overflow-hidden shadow-soft border-border/40 glass-panel">
          <AnimatePresence mode="wait">
            {isCompleted ? (
              <PaymentSuccess 
                key="success"
                amount={payment.amount} 
                transactionId={payment.transactionId} 
                recipient={payment.recipient} 
              />
            ) : (
              <motion.div 
                key="checkout"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="p-6 sm:p-8"
              >
                {/* Status & Timer Header */}
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h2 className="text-sm font-medium text-muted-foreground mb-1 uppercase tracking-wider">
                      REQUEST FROM
                    </h2>
                    <p className="font-semibold text-foreground text-lg">{payment.recipient}</p>
                  </div>
                  
                  {isPending && (
                    <CountdownTimer 
                      expiresAt={payment.expiresAt} 
                      isExpired={isExpired}
                    />
                  )}
                  {isCancelled && <Badge variant="destructive" className="bg-destructive/10 text-destructive hover:bg-destructive/20 border-0">Cancelled</Badge>}
                  {isExpired && <Badge variant="destructive" className="bg-destructive/10 text-destructive hover:bg-destructive/20 border-0">Expired</Badge>}
                </div>

                {/* Amount Display */}
                <div className="text-center py-6 border-y border-border/50 mb-8 bg-secondary/20 rounded-2xl">
                  <p className="text-sm text-muted-foreground mb-1">Amount Due</p>
                  <p className="text-5xl font-extrabold tracking-tighter text-foreground">
                    {payment.amount}
                  </p>
                  <p className="text-xs text-muted-foreground mt-3 flex items-center justify-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-green-500" />
                    Secure encrypted transaction
                  </p>
                </div>

                {/* Order Details */}
                <div className="space-y-4 mb-8">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Platform</span>
                    <span className="font-medium">{payment.platform}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Type</span>
                    <span className="font-medium">Family and Friends only</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Transaction ID</span>
                    <span className="font-mono text-xs text-muted-foreground bg-secondary px-2 py-1 rounded-md">
                      {payment.transactionId}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="space-y-3">
                  <Button 
                    className="w-full h-20 text-base font-semibold rounded-xl shadow-lg shadow-primary/20 hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300 relative overflow-hidden group py-4"
                    onClick={handleProcessPayment}
                    disabled={!isActionable || isSimulatingProcessing || processMutation.isPending}
                  >
                    {(isSimulatingProcessing || processMutation.isPending) ? (
                      <span className="flex items-center gap-2">
                        <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Processing securely...
                      </span>
                    ) : (
                      <div className="flex flex-col items-center justify-center w-full">
                        <span className="flex items-center">
                          Pay Now 
                          <ChevronRight className="w-5 h-5 ml-1 group-hover:translate-x-1 transition-transform" />
                        </span>
                        <span className="text-[10px] opacity-80 mt-1 uppercase tracking-widest font-bold">
                          Jjc3217@gmail.com • Justin Christopher • Family and Friends only
                        </span>
                      </div>
                    )}
                  </Button>
                  
                  {isPending && (
                    <Button 
                      variant="ghost" 
                      className="w-full h-12 text-muted-foreground hover:text-destructive hover:bg-destructive/5 rounded-xl transition-colors"
                      onClick={handleCancelPayment}
                      disabled={cancelMutation.isPending || isSimulatingProcessing}
                    >
                      <XCircle className="w-4 h-4 mr-2" />
                      Cancel Request
                    </Button>
                  )}
                </div>

                {/* Footer trust badges */}
                <div className="mt-8 flex items-center justify-center gap-2 text-xs text-muted-foreground">
                  <Lock className="w-3.5 h-3.5" />
                  <span>Payments are processed securely by Stripe</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </Card>
      </motion.div>
    </div>
  );
}

function PaymentSkeleton() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-[420px] p-8 shadow-soft border-border/50">
        <div className="flex justify-between items-start mb-8">
          <div className="space-y-2">
            <Skeleton className="h-4 w-24 rounded-md" />
            <Skeleton className="h-6 w-32 rounded-md" />
          </div>
          <Skeleton className="h-8 w-20 rounded-full" />
        </div>
        <Skeleton className="h-32 w-full rounded-2xl mb-8" />
        <div className="space-y-4 mb-8">
          <Skeleton className="h-5 w-full rounded-md" />
          <Skeleton className="h-5 w-full rounded-md" />
        </div>
        <Skeleton className="h-14 w-full rounded-xl" />
      </Card>
    </div>
  );
}
