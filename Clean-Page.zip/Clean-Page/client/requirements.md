## Packages
framer-motion | Page transitions and success animations
date-fns | Reliable date formatting and countdown calculations
lucide-react | High-quality icons for UI elements

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
}
